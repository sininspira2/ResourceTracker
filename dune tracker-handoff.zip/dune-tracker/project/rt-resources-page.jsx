/* Resources / Dashboard page */

function SearchInput({ value, onChange, placeholder }) {
  return (
    <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
      <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--fg-4)" }}>
        <Icon name="search" size={14} />
      </span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%", height: 36,
          paddingLeft: 34, paddingRight: 12,
          background: "var(--bg-2)", border: "1px solid var(--line)",
          borderRadius: 8, color: "var(--fg-1)",
          fontSize: 13, fontFamily: "inherit",
          outline: "none",
        }}
        onFocus={(e) => e.target.style.borderColor = "var(--accent)"}
        onBlur={(e) => e.target.style.borderColor = "var(--line)"}
      />
    </div>
  );
}

function Select({ value, onChange, options, label }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--fg-3)" }}>
      {label && <span>{label}</span>}
      <div style={{ position: "relative" }}>
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{
            appearance: "none",
            height: 32, padding: "0 28px 0 10px",
            background: "var(--bg-2)", border: "1px solid var(--line)",
            borderRadius: 7, color: "var(--fg-1)",
            fontSize: 12.5, fontFamily: "inherit",
            outline: "none", cursor: "pointer",
          }}
        >
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <span style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", color: "var(--fg-4)" }}>
          <Icon name="chevron-down" size={12} />
        </span>
      </div>
    </label>
  );
}

function Toggle({ checked, onChange, label, count }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "var(--fg-2)", cursor: "pointer", userSelect: "none" }}>
      <span
        onClick={() => onChange(!checked)}
        style={{
          width: 32, height: 18, borderRadius: 999,
          background: checked ? "var(--accent)" : "var(--bg-3)",
          position: "relative",
          transition: "background 120ms ease",
        }}
      >
        <span style={{
          position: "absolute", top: 2, left: checked ? 16 : 2,
          width: 14, height: 14, borderRadius: 999,
          background: "oklch(0.98 0 0)",
          transition: "left 120ms ease",
          boxShadow: "0 1px 2px oklch(0 0 0 / 0.3)",
        }} />
      </span>
      <span>{label}</span>
      {count !== undefined && <span className="mono" style={{ color: "var(--fg-4)", fontSize: 11.5 }}>({count})</span>}
    </label>
  );
}

function KPI({ label, value, hint, tone = "default", icon }) {
  const colors = {
    default: { fg: "var(--fg-1)", bg: "var(--bg-1)" },
    ok: { fg: "var(--ok)", bg: "var(--ok-soft)" },
    warn: { fg: "var(--warn)", bg: "var(--warn-soft)" },
    crit: { fg: "var(--crit)", bg: "var(--crit-soft)" },
    accent: { fg: "var(--accent)", bg: "var(--accent-soft)" },
  }[tone];
  return (
    <Card padded={false} style={{ padding: "14px 16px", background: "var(--bg-1)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 8 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: "var(--fg-3)", letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</div>
        {icon && (
          <div style={{
            width: 24, height: 24, borderRadius: 6,
            background: colors.bg, color: colors.fg,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}><Icon name={icon} size={13} /></div>
        )}
      </div>
      <div className="mono" style={{ fontSize: 22, fontWeight: 600, color: colors.fg, letterSpacing: -0.3, lineHeight: 1.1 }}>
        {value}
      </div>
      {hint && <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 4 }}>{hint}</div>}
    </Card>
  );
}

function RecentUpdateRow({ item }) {
  const isDelta = typeof item.delta === "number" && item.delta !== 0;
  const pos = item.delta > 0;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 12px",
      background: "var(--bg-2)",
      borderRadius: 8,
      border: "1px solid var(--line)",
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: 999,
        background: isDelta ? (pos ? "var(--ok)" : "var(--crit)") : "var(--fg-4)",
        flexShrink: 0,
      }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--fg-1)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {item.target}
        </div>
        <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 1 }}>
          By <span style={{ color: "var(--fg-2)" }}>{item.user}</span> · {item.when}
        </div>
      </div>
      {isDelta && (
        <span className="mono" style={{
          fontSize: 13, fontWeight: 600,
          color: pos ? "var(--ok)" : "var(--crit)",
        }}>{fmtDelta(item.delta)}</span>
      )}
      {!isDelta && item.meta && (
        <span style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--font-mono)" }}>{item.meta}</span>
      )}
    </div>
  );
}

function LeaderRow({ leader, isYou }) {
  const rankColors = {
    1: { bg: "linear-gradient(135deg, oklch(0.75 0.14 85), oklch(0.65 0.15 50))", fg: "oklch(0.15 0 0)" },
    2: { bg: "var(--bg-3)", fg: "var(--fg-1)" },
    3: { bg: "linear-gradient(135deg, oklch(0.65 0.13 40), oklch(0.55 0.12 30))", fg: "oklch(0.98 0 0)" },
  }[leader.rank] || { bg: "var(--bg-3)", fg: "var(--fg-2)" };
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 12px",
      background: isYou ? "var(--accent-soft)" : "var(--bg-2)",
      borderRadius: 8,
      border: isYou ? "1px solid color-mix(in oklch, var(--accent) 30%, transparent)" : "1px solid var(--line)",
    }}>
      <div className="mono" style={{
        minWidth: 28, height: 24, padding: "0 6px",
        display: "flex", alignItems: "center", justifyContent: "center",
        background: rankColors.bg, color: rankColors.fg,
        borderRadius: 6, fontSize: 11, fontWeight: 700,
      }}>#{leader.rank}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--fg-1)" }}>
          {leader.user}{isYou && <span style={{ fontSize: 10.5, color: "var(--accent)", marginLeft: 6, fontWeight: 600 }}>YOU</span>}
        </div>
        <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 1 }}>{leader.actions} actions</div>
      </div>
      <div className="mono" style={{ fontSize: 13.5, fontWeight: 600, color: "var(--fg-1)" }}>
        {leader.points.toFixed(1)} <span style={{ fontSize: 10.5, color: "var(--fg-3)", marginLeft: 2 }}>pts</span>
      </div>
    </div>
  );
}

function ResourceCard({ r, density, onOpen }) {
  const pad = density === "compact" ? 12 : 16;
  const imgSize = density === "compact" ? "md" : "lg";
  const pct = r.target > 0 ? (r.total / r.target) * 100 : null;
  const [hover, setHover] = useState(false);
  const accent = `var(${statusMeta[r.status]?.cvar || "--fg-3"})`;

  return (
    <div
      onClick={onOpen}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: "var(--bg-1)",
        border: "1px solid var(--line)",
        borderRadius: 12,
        padding: pad,
        display: "flex", flexDirection: "column", gap: density === "compact" ? 10 : 12,
        cursor: "pointer",
        transition: "transform 140ms ease, border-color 140ms ease, box-shadow 140ms ease",
        transform: hover ? "translateY(-1px)" : "translateY(0)",
        borderColor: hover ? "color-mix(in oklch, var(--accent) 50%, var(--line))" : "var(--line)",
        boxShadow: hover ? "0 6px 24px oklch(0 0 0 / 0.25)" : "var(--shadow-sm)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* accent left bar */}
      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: accent, opacity: 0.75 }} />

      {/* Header: image + name + status */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <ResourceImage resource={r} size={imgSize} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: density === "compact" ? 13.5 : 14.5, fontWeight: 600, color: "var(--fg-1)", lineHeight: 1.25, marginBottom: 4 }}>
            {r.name}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
            <StatusChip status={r.status} />
            {r.target > 0 && (
              <Chip mono color="var(--fg-3)" soft="var(--bg-2)">
                {pct >= 100 ? `${Math.round(pct)}%` : `${Math.round(pct)}%`}
              </Chip>
            )}
          </div>
        </div>
      </div>

      {/* Quantities + sparkline */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr auto",
        gap: 10,
        alignItems: "end",
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 6 }}>
            <span className="mono" style={{ fontSize: density === "compact" ? 20 : 24, fontWeight: 600, color: "var(--fg-1)", letterSpacing: -0.5, lineHeight: 1 }}>
              {fmtNum(r.total)}
            </span>
            <span style={{ fontSize: 11, color: "var(--fg-3)" }}>total</span>
          </div>
          <div style={{ display: "flex", gap: 10, fontSize: 11, color: "var(--fg-3)" }}>
            <span><span style={{ color: "var(--fg-4)" }}>H</span> <span className="mono" style={{ color: "var(--fg-2)" }}>{fmtNum(r.q1)}</span></span>
            <span><span style={{ color: "var(--fg-4)" }}>DD</span> <span className="mono" style={{ color: "var(--fg-2)" }}>{fmtNum(r.q2)}</span></span>
          </div>
        </div>
        <Sparkline data={r.spark} w={68} h={30} stroke={accent} />
      </div>

      {/* Progress */}
      {r.target > 0 ? (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10.5, color: "var(--fg-3)", marginBottom: 5 }}>
            <span>Progress</span>
            <span className="mono">{fmtNum(r.total)} / {fmtNum(r.target)}</span>
          </div>
          <Progress value={r.total} max={r.target} status={r.status} />
        </div>
      ) : (
        <div style={{ fontSize: 11, color: "var(--fg-4)", fontStyle: "italic" }}>No target set</div>
      )}

      {/* Footer: updater */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        fontSize: 11, color: "var(--fg-3)",
        borderTop: "1px solid var(--line)",
        paddingTop: density === "compact" ? 8 : 10,
      }}>
        <span>by <span style={{ color: "var(--fg-2)" }}>{r.updater}</span></span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <Icon name="clock" size={11} />
          {r.when}
        </span>
      </div>
    </div>
  );
}

function CategorySection({ title, resources, density, onOpen }) {
  const cat = CATEGORIES[resources[0].category] || CATEGORIES.other;
  const gridCols = density === "compact" ? "repeat(auto-fill, minmax(220px, 1fr))" : "repeat(auto-fill, minmax(260px, 1fr))";
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <span style={{
          width: 4, height: 18, borderRadius: 2,
          background: cat.c,
        }} />
        <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "var(--fg-1)" }}>{title}</h3>
        <span className="mono" style={{
          fontSize: 11, color: "var(--fg-3)",
          background: "var(--bg-2)", border: "1px solid var(--line)",
          padding: "2px 8px", borderRadius: 999,
        }}>{resources.length}</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: gridCols, gap: 12 }}>
        {resources.map(r => <ResourceCard key={r.id} r={r} density={density} onOpen={() => onOpen(r)} />)}
      </div>
    </div>
  );
}

function AdminBar() {
  return (
    <Card padded={false} style={{
      padding: "14px 18px",
      background: "linear-gradient(90deg, color-mix(in oklch, var(--crit) 12%, var(--bg-1)) 0%, var(--bg-1) 60%)",
      borderColor: "color-mix(in oklch, var(--crit) 30%, var(--line))",
      display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8,
          background: "var(--crit-soft)", color: "var(--crit)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}><Icon name="shield" size={15} /></div>
        <div>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--fg-1)" }}>Admin Panel</div>
          <div style={{ fontSize: 11.5, color: "var(--fg-3)" }}>You can create, edit, and manage all resources.</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <Btn variant="ghost" size="sm" icon={<Icon name="filter" size={13} />}>Bulk Import</Btn>
        <Btn variant="ghost" size="sm" icon={<Icon name="external" size={13} />}>Export</Btn>
        <Btn variant="primary" size="sm" icon={<Icon name="plus" size={13} />}>Add Resource</Btn>
      </div>
    </Card>
  );
}

function ResourcesPage({ density, onOpen }) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [cat, setCat] = useState("all");
  const [view, setView] = useState("grid");
  const [needsUpdate, setNeedsUpdate] = useState(false);
  const [priority, setPriority] = useState(false);

  const filtered = useMemo(() => {
    return RESOURCES.filter(r => {
      if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (status !== "all" && r.status !== status) return false;
      if (cat !== "all" && r.category !== cat) return false;
      return true;
    });
  }, [search, status, cat]);

  const byCategory = useMemo(() => {
    const groups = {};
    filtered.forEach(r => {
      const key = r.sub || CATEGORIES[r.category].label;
      groups[key] = groups[key] || [];
      groups[key].push(r);
    });
    return groups;
  }, [filtered]);

  const kpis = useMemo(() => {
    const crit = RESOURCES.filter(r => r.status === "critical").length;
    const below = RESOURCES.filter(r => r.status === "below").length;
    const above = RESOURCES.filter(r => r.status === "above").length;
    const at = RESOURCES.filter(r => r.status === "at-target").length;
    return { crit, below, above, at, total: RESOURCES.length };
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Page header */}
      <div>
        <div style={{ fontSize: 11, color: "var(--fg-3)", letterSpacing: 0.5, textTransform: "uppercase", fontWeight: 600, marginBottom: 6 }}>Overview</div>
        <h1 style={{ margin: 0, fontSize: 26, fontWeight: 700, color: "var(--fg-1)", letterSpacing: -0.3 }}>Resource Management</h1>
        <p style={{ margin: "6px 0 0", fontSize: 13.5, color: "var(--fg-3)" }}>
          Track and manage your guild's resources in real-time.
        </p>
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12 }}>
        <KPI label="Critical" value={kpis.crit} hint="need attention" tone="crit" icon="trend-down" />
        <KPI label="Below Target" value={kpis.below} hint="incoming" tone="warn" icon="trend-down" />
        <KPI label="At / Above" value={kpis.at + kpis.above} hint={`${kpis.at} at, ${kpis.above} above`} tone="ok" icon="trend-up" />
        <KPI label="Tracked" value={kpis.total} hint="total resources" icon="layers" />
      </div>

      {/* Two-up: recent + leaderboard */}
      <div style={{ display: "grid", gridTemplateColumns: "3fr 2fr", gap: 16 }} className="rt-two-up">
        <Card>
          <SectionHeader
            title="Recent Updates"
            subtitle="Latest changes across the tracker"
            right={<Btn variant="ghost" size="sm" icon={<Icon name="clock" size={13} />}>Last 24h</Btn>}
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {ACTIVITY.slice(0, 5).map(a => <RecentUpdateRow key={a.id} item={a} />)}
          </div>
        </Card>
        <Card>
          <SectionHeader
            title={<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="trophy" size={14} color="var(--accent)" /> Leaderboard</span>}
            right={
              <Select
                value="7d"
                onChange={() => {}}
                options={[{ value: "7d", label: "Last 7 days" }, { value: "30d", label: "Last 30 days" }, { value: "all", label: "All time" }]}
              />
            }
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {LEADERS.slice(0, 3).map(l => <LeaderRow key={l.rank} leader={l} isYou={l.user === "sininspira"} />)}
            <Btn variant="subtle" size="md" style={{ marginTop: 4, width: "100%", justifyContent: "center" }}>
              View Full Leaderboard
            </Btn>
          </div>
        </Card>
      </div>

      <AdminBar />

      {/* Filter bar */}
      <Card padded={false} style={{ padding: 14 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <SearchInput value={search} onChange={setSearch} placeholder="Search resources…" />
          <div style={{ display: "flex", gap: 6, background: "var(--bg-2)", border: "1px solid var(--line)", borderRadius: 7, padding: 3 }}>
            <button onClick={() => setView("table")}
              style={{ height: 28, padding: "0 10px", fontSize: 12, display: "inline-flex", alignItems: "center", gap: 5,
                background: view === "table" ? "var(--bg-1)" : "transparent",
                color: view === "table" ? "var(--fg-1)" : "var(--fg-3)",
                border: "none", borderRadius: 5, fontWeight: 500, cursor: "pointer" }}>
              <Icon name="list" size={13} /> Table
            </button>
            <button onClick={() => setView("grid")}
              style={{ height: 28, padding: "0 10px", fontSize: 12, display: "inline-flex", alignItems: "center", gap: 5,
                background: view === "grid" ? "var(--bg-1)" : "transparent",
                color: view === "grid" ? "var(--fg-1)" : "var(--fg-3)",
                border: "none", borderRadius: 5, fontWeight: 500, cursor: "pointer" }}>
              <Icon name="grid" size={13} /> Grid
            </button>
          </div>
        </div>
        <div style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap", marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--line)" }}>
          <Select
            label="Status"
            value={status}
            onChange={setStatus}
            options={[
              { value: "all", label: `All (${RESOURCES.length})` },
              { value: "critical", label: `Critical (${kpis.crit})` },
              { value: "below", label: `Below (${kpis.below})` },
              { value: "at-target", label: `At Target (${kpis.at})` },
              { value: "above", label: `Above (${kpis.above})` },
            ]}
          />
          <Select
            label="Category"
            value={cat}
            onChange={setCat}
            options={[
              { value: "all", label: `All (${RESOURCES.length})` },
              ...Object.entries(CATEGORIES).map(([k, v]) => ({ value: k, label: v.label })),
            ]}
          />
          <Toggle checked={needsUpdate} onChange={setNeedsUpdate} label="Needs updating" count={7} />
          <Toggle checked={priority} onChange={setPriority} label="Priority" />
          <span style={{ flex: 1 }} />
          <span style={{ fontSize: 11.5, color: "var(--fg-3)", display: "inline-flex", alignItems: "center", gap: 6 }}>
            <Icon name="sparkle" size={12} color="var(--accent)" />
            Click any resource to view history & analytics
          </span>
        </div>
      </Card>

      {/* Resource groups */}
      {Object.entries(byCategory).map(([name, group]) => (
        <CategorySection key={name} title={name} resources={group} density={density} onOpen={onOpen} />
      ))}

      <style>{`
        @media (max-width: 900px) {
          .rt-two-up { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

Object.assign(window, { ResourcesPage });
