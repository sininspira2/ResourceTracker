/* Root app: layout + tweaks + page routing */

const ACCENTS = [
  { id: "amber",  label: "Amber",  hue: 60,  swatch: "oklch(0.78 0.14 60)" },
  { id: "blue",   label: "Blue",   hue: 240, swatch: "oklch(0.72 0.14 240)" },
  { id: "rose",   label: "Rose",   hue: 25,  swatch: "oklch(0.70 0.17 25)" },
  { id: "emerald",label: "Emerald",hue: 150, swatch: "oklch(0.70 0.14 150)" },
  { id: "violet", label: "Violet", hue: 290, swatch: "oklch(0.70 0.15 290)" },
];

const TWEAKS_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "amber",
  "theme": "dark",
  "density": "comfortable"
}/*EDITMODE-END*/;

function useMedia(q) {
  const [m, setM] = useState(() => window.matchMedia(q).matches);
  useEffect(() => {
    const mql = window.matchMedia(q);
    const h = (e) => setM(e.matches);
    mql.addEventListener("change", h);
    return () => mql.removeEventListener("change", h);
  }, [q]);
  return m;
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAKS_DEFAULTS);
  const [page, setPage] = useState("resources"); // resources | details
  const [activeResource, setActiveResource] = useState(RESOURCES.find(r => r.id === "spice-melange"));
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const isMobile = useMedia("(max-width: 820px)");

  // Apply theme + accent
  useEffect(() => {
    const sys = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const t = tweaks.theme === "system" ? (sys ? "dark" : "light") : tweaks.theme;
    document.documentElement.setAttribute("data-theme", t);
  }, [tweaks.theme]);

  useEffect(() => {
    const acc = ACCENTS.find(a => a.id === tweaks.accent) || ACCENTS[0];
    document.documentElement.style.setProperty("--accent-h", acc.hue);
  }, [tweaks.accent]);

  const openResource = (r) => { setActiveResource(r); setPage("details"); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const backToList = () => { setPage("resources"); window.scrollTo({ top: 0 }); };

  const setCurrentNav = (id) => {
    if (id === "resources") setPage("resources");
    else setPage(id);
  };
  const currentNav = page === "details" ? "resources" : page;

  const density = tweaks.density || "comfortable";

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg-0)" }}>
      {!isMobile && (
        <Sidebar
          current={currentNav}
          setCurrent={setCurrentNav}
          theme={tweaks.theme}
          setTheme={(t) => setTweak("theme", t)}
          collapsed={sidebarCollapsed}
          setCollapsed={setSidebarCollapsed}
        />
      )}
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        {isMobile && (
          <MobileTopBar
            current={currentNav}
            setCurrent={setCurrentNav}
            theme={tweaks.theme}
            setTheme={(t) => setTweak("theme", t)}
          />
        )}
        <main style={{
          flex: 1,
          padding: isMobile ? "16px" : "28px 36px",
          maxWidth: 1400,
          width: "100%",
          margin: "0 auto",
        }}>
          {page === "resources" && <ResourcesPage density={density} onOpen={openResource} />}
          {page === "details" && <DetailsPage resource={activeResource} onBack={backToList} density={density} />}
          {page !== "resources" && page !== "details" && (
            <PlaceholderPage label={NAV_ITEMS.find(n => n.id === page)?.label || page} />
          )}
        </main>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Theme">
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            {["light", "dark", "system"].map(t => (
              <button
                key={t}
                onClick={() => setTweak("theme", t)}
                style={{
                  flex: 1, height: 32,
                  background: tweaks.theme === t ? "var(--accent-soft)" : "var(--bg-2)",
                  color: tweaks.theme === t ? "var(--accent)" : "var(--fg-2)",
                  border: "1px solid " + (tweaks.theme === t ? "var(--accent)" : "var(--line)"),
                  borderRadius: 7,
                  fontSize: 12, fontWeight: 500,
                  textTransform: "capitalize",
                  cursor: "pointer",
                }}
              >{t}</button>
            ))}
          </div>
        </TweakSection>

        <TweakSection title="Accent color">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 6 }}>
            {ACCENTS.map(a => (
              <button
                key={a.id}
                onClick={() => setTweak("accent", a.id)}
                title={a.label}
                style={{
                  height: 36,
                  background: a.swatch,
                  border: tweaks.accent === a.id ? "2px solid var(--fg-1)" : "2px solid transparent",
                  boxShadow: tweaks.accent === a.id ? "0 0 0 2px var(--bg-1) inset" : "none",
                  borderRadius: 8,
                  cursor: "pointer",
                }}
              />
            ))}
          </div>
        </TweakSection>

        <TweakSection title="Card density">
          <div style={{ display: "flex", gap: 6 }}>
            {["compact", "comfortable"].map(d => (
              <button
                key={d}
                onClick={() => setTweak("density", d)}
                style={{
                  flex: 1, height: 32,
                  background: tweaks.density === d ? "var(--accent-soft)" : "var(--bg-2)",
                  color: tweaks.density === d ? "var(--accent)" : "var(--fg-2)",
                  border: "1px solid " + (tweaks.density === d ? "var(--accent)" : "var(--line)"),
                  borderRadius: 7,
                  fontSize: 12, fontWeight: 500,
                  textTransform: "capitalize",
                  cursor: "pointer",
                }}
              >{d}</button>
            ))}
          </div>
        </TweakSection>

        <TweakSection title="Quick nav">
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <button
              onClick={() => setPage("resources")}
              style={{
                padding: "8px 10px", textAlign: "left", fontSize: 12.5,
                background: page === "resources" ? "var(--accent-soft)" : "var(--bg-2)",
                color: page === "resources" ? "var(--accent)" : "var(--fg-2)",
                border: "1px solid var(--line)", borderRadius: 7, cursor: "pointer",
              }}
            >📋 Resources page</button>
            <button
              onClick={() => { setActiveResource(RESOURCES.find(r => r.id === "spice-melange")); setPage("details"); }}
              style={{
                padding: "8px 10px", textAlign: "left", fontSize: 12.5,
                background: page === "details" ? "var(--accent-soft)" : "var(--bg-2)",
                color: page === "details" ? "var(--accent)" : "var(--fg-2)",
                border: "1px solid var(--line)", borderRadius: 7, cursor: "pointer",
              }}
            >🔍 Resource details page</button>
          </div>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

function PlaceholderPage({ label }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 26, fontWeight: 700, color: "var(--fg-1)" }}>{label}</h1>
        <p style={{ margin: "6px 0 0", fontSize: 13.5, color: "var(--fg-3)" }}>This page isn't part of the current polish scope — focus is on Resources and Details.</p>
      </div>
      <Card>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, padding: "56px 20px", textAlign: "center" }}>
          <div style={{ width: 56, height: 56, borderRadius: 12, background: "var(--accent-soft)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="sparkle" size={26} />
          </div>
          <div style={{ fontSize: 15, fontWeight: 600, color: "var(--fg-1)" }}>Uses the same nav, cards and tokens</div>
          <p style={{ margin: 0, maxWidth: 420, fontSize: 13, color: "var(--fg-3)", lineHeight: 1.5 }}>
            Same sidebar, theme switch, accent, typography and component library you see on the other pages — ready to extend when you'd like to polish this view.
          </p>
        </div>
      </Card>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
