/* Seed data & helpers for the Resource Tracker prototype */

const TIERS = [
  { id: 0, label: "T0", bg: "oklch(0.40 0.01 60)", fg: "oklch(0.90 0 0)" },
  { id: 1, label: "T1", bg: "oklch(0.55 0.13 80)", fg: "oklch(0.15 0 0)" },
  { id: 2, label: "T2", bg: "oklch(0.55 0.14 260)", fg: "oklch(0.95 0 0)" },
  { id: 3, label: "T3", bg: "oklch(0.65 0.14 350)", fg: "oklch(0.15 0 0)" },
  { id: 4, label: "T4", bg: "oklch(0.62 0.14 150)", fg: "oklch(0.15 0 0)" },
  { id: 5, label: "T5", bg: "oklch(0.68 0.15 75)", fg: "oklch(0.15 0 0)" },
  { id: 6, label: "T6", bg: "oklch(0.60 0.13 230)", fg: "oklch(0.95 0 0)" },
];

const CATEGORIES = {
  raw: { label: "Raw", c: "oklch(0.68 0.15 50)" },
  refined: { label: "Refined", c: "oklch(0.65 0.14 230)" },
  components: { label: "Components", c: "oklch(0.62 0.14 150)" },
  other: { label: "Other", c: "oklch(0.65 0.15 300)" },
  bp: { label: "Blueprints", c: "oklch(0.65 0.15 290)" },
};

// Build a sparkline: 14 points of trend data
const spark = (seed, trend = 0, vol = 0.3) => {
  const pts = [];
  let v = 0.5 + ((seed * 9301 + 49297) % 233280) / 466560;
  for (let i = 0; i < 14; i++) {
    const n = ((seed * (i + 7) * 2654435761) % 1000) / 1000 - 0.5;
    v = Math.max(0.05, Math.min(0.95, v + n * vol + trend * 0.04));
    pts.push(v);
  }
  return pts;
};

const R = (name, category, tier, q1, q2, target, status, updater, when, trend = 0, sub = "") => ({
  id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
  name,
  category,
  sub: sub || CATEGORIES[category].label,
  tier,
  q1, q2,
  total: q1 + q2,
  target,
  status,
  updater,
  when,
  spark: spark(name.length + tier * 7 + q1 % 17, trend, 0.25),
  trend,
});

const RESOURCES = [
  // RAW
  R("Agave Seeds", "raw", 1, 29, 0, 400, "critical", "sininspira", "1 week ago", -0.2),
  R("Aluminum Ore", "raw", 2, 2, 0, 0, "at-target", "sininspira", "5 days ago", 0.1),
  R("Basalt Stone", "raw", 0, 53, 0, 0, "at-target", "sininspira", "Just now", 0.4),
  R("Carbon Ore", "raw", 1, 5128, 0, 0, "at-target", "sininspira", "5 days ago", 0.3),
  R("Copper Ore", "raw", 1, 0, 0, 0, "at-target", "sininspira", "1 week ago", 0.0),
  R("Erythrite Crystal", "raw", 3, 188, 12, 500, "below", "jess", "2 days ago", 0.15),
  R("Iron Ore", "raw", 2, 3402, 840, 2000, "above", "sininspira", "3 hours ago", 0.6),
  R("Jasmium Crystal", "raw", 4, 84, 16, 250, "below", "khael", "6 hours ago", -0.1),
  R("Silicate", "raw", 1, 1890, 120, 1500, "above", "sininspira", "Yesterday", 0.4),
  R("Titanium Ore", "raw", 3, 912, 64, 1200, "below", "vara", "4 hours ago", 0.2),

  // REFINED
  R("Spice Melange", "refined", 5, 24984, 0, 5000, "above", "sininspira", "9 hours ago", 0.8, "Refined Resources"),
  R("Plastanium Ingot", "refined", 6, 1188, 88, 2000, "below", "sininspira", "13 hours ago", -0.4, "Refined Resources"),
  R("Steel Ingot", "refined", 2, 2400, 300, 3000, "below", "jess", "Yesterday", 0.2, "Refined Resources"),
  R("Duraluminum Ingot", "refined", 4, 420, 20, 1000, "critical", "khael", "2 days ago", -0.3, "Refined Resources"),
  R("Plasteel Plate", "refined", 5, 640, 40, 500, "above", "sininspira", "7 hours ago", 0.5, "Refined Resources"),

  // COMPONENTS
  R("Hummingbird Wing Module Mk6 BP", "bp", 6, 0, 0, 5, "critical", "sininspira", "50 min ago", 0.0, "Gear Blueprints"),
  R("Steady Assault Boost Module Mk6 BP", "bp", 6, 0, 0, 5, "critical", "sininspira", "51 min ago", 0.0, "Gear Blueprints"),
  R("Holtzman Actuator", "components", 5, 42, 8, 50, "below", "vara", "3 hours ago", 0.3, "Components"),
  R("Servok Relay", "components", 4, 180, 22, 100, "above", "jess", "6 hours ago", 0.4, "Components"),
  R("Heat Sink", "components", 3, 96, 14, 120, "below", "sininspira", "11 hours ago", -0.1, "Components"),
];

const ACTIVITY = [
  { id: 1, user: "sininspira", action: "updated", target: "Spice Melange", delta: +14857, when: "13 hours ago" },
  { id: 2, user: "sininspira", action: "removed", target: "Spice Melange", delta: -12060, when: "13 hours ago" },
  { id: 3, user: "sininspira", action: "removed", target: "Plastanium Ingot", delta: -1188, when: "13 hours ago" },
  { id: 4, user: "sininspira", action: "added", target: "Iron Ore", delta: +2400, when: "3 hours ago" },
  { id: 5, user: "jess", action: "set target", target: "Servok Relay", delta: 0, when: "6 hours ago", meta: "target → 100" },
  { id: 6, user: "vara", action: "transferred", target: "Holtzman Actuator", delta: 0, when: "4 hours ago", meta: "DD → Hagga × 20" },
  { id: 7, user: "khael", action: "added", target: "Erythrite Crystal", delta: +40, when: "2 days ago" },
];

const LEADERS = [
  { rank: 1, user: "sininspira", actions: 72, points: 101.0 },
  { rank: 2, user: "jess", actions: 18, points: 42.0 },
  { rank: 3, user: "vara", actions: 11, points: 24.0 },
  { rank: 4, user: "khael", actions: 6, points: 10.0 },
];

const fmtNum = (n) => {
  if (n === null || n === undefined) return "—";
  if (Math.abs(n) >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  return n.toLocaleString("en-US");
};

const fmtDelta = (n) => (n > 0 ? "+" : "") + fmtNum(n);

const statusMeta = {
  critical: { label: "Critical", cvar: "--crit", cvarSoft: "--crit-soft" },
  below: { label: "Below Target", cvar: "--warn", cvarSoft: "--warn-soft" },
  "at-target": { label: "At Target", cvar: "--ok", cvarSoft: "--ok-soft" },
  above: { label: "Above Target", cvar: "--above", cvarSoft: "--above-soft" },
  "no-target": { label: "No Target", cvar: "--info", cvarSoft: "--info-soft" },
};

Object.assign(window, {
  TIERS, CATEGORIES, RESOURCES, ACTIVITY, LEADERS,
  fmtNum, fmtDelta, statusMeta,
});
