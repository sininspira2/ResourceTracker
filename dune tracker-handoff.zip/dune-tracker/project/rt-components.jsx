/* Shared UI primitives for the Resource Tracker prototype */

const { useState, useRef, useEffect, useMemo } = React;

function Chip({ children, color = "var(--fg-2)", soft = "var(--bg-3)", mono, className = "", style }) {
  return (
    <span
      className={className}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        fontSize: 11,
        fontWeight: 600,
        lineHeight: 1,
        padding: "4px 8px",
        borderRadius: 999,
        background: soft,
        color: color,
        fontFamily: mono ? "var(--font-mono)" : "inherit",
        letterSpacing: 0.1,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {children}
    </span>
  );
}

function TierPill({ tier }) {
  const t = TIERS[tier] || TIERS[0];
  return (
    <span
      className="mono"
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minWidth: 26,
        height: 18,
        padding: "0 6px",
        fontSize: 10.5,
        fontWeight: 700,
        background: t.bg,
        color: t.fg,
        borderRadius: 4,
        letterSpacing: 0.3,
      }}
    >
      {t.label}
    </span>
  );
}

function StatusDot({ status }) {
  const c = `var(${statusMeta[status]?.cvar || "--fg-3"})`;
  return (
    <span
      style={{
        width: 8, height: 8, borderRadius: 999,
        background: c,
        boxShadow: `0 0 0 3px color-mix(in oklch, ${c} 22%, transparent)`,
        flexShrink: 0,
      }}
    />
  );
}

function StatusChip({ status }) {
  const m = statusMeta[status];
  if (!m) return null;
  return (
    <Chip color={`var(${m.cvar})`} soft={`var(${m.cvarSoft})`}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: `var(${m.cvar})` }} />
      {m.label}
    </Chip>
  );
}

function Sparkline({ data, w = 72, h = 22, stroke = "var(--accent)", fill = true, strokeWidth = 1.5 }) {
  if (!data || !data.length) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pad = 2;
  const pts = data.map((v, i) => {
    const x = pad + (i / (data.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return [x, y];
  });
  const d = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
  const area = `${d} L${pts[pts.length - 1][0]},${h} L${pts[0][0]},${h} Z`;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: "block", overflow: "visible" }}>
      {fill && <path d={area} fill={stroke} opacity="0.14" />}
      <path d={d} fill="none" stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r={1.8} fill={stroke} />
    </svg>
  );
}

function Progress({ value, max, status, height = 6 }) {
  const pct = Math.min(1.5, max > 0 ? value / max : 0);
  const overflowPct = Math.min(1, pct);
  const color = `var(${statusMeta[status]?.cvar || "--accent"})`;
  return (
    <div
      style={{
        position: "relative",
        height,
        width: "100%",
        background: "var(--bg-3)",
        borderRadius: 999,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          width: `${overflowPct * 100}%`,
          background: color,
          borderRadius: 999,
          transition: "width 300ms ease",
        }}
      />
    </div>
  );
}

function Btn({ children, variant = "ghost", icon, size = "md", onClick, title, style, active }) {
  const sizes = {
    sm: { h: 28, px: 10, fs: 12.5, gap: 6 },
    md: { h: 34, px: 12, fs: 13.5, gap: 7 },
    lg: { h: 40, px: 16, fs: 14, gap: 8 },
  }[size];
  const variants = {
    primary: { bg: "var(--accent)", fg: "var(--accent-fg)", hoverBg: "var(--accent-2)", border: "transparent" },
    secondary: { bg: "var(--bg-2)", fg: "var(--fg-1)", hoverBg: "var(--bg-3)", border: "var(--line)" },
    ghost: { bg: "transparent", fg: "var(--fg-2)", hoverBg: "var(--bg-2)", border: "transparent" },
    danger: { bg: "var(--crit-soft)", fg: "var(--crit)", hoverBg: "color-mix(in oklch, var(--crit) 25%, transparent)", border: "transparent" },
    success: { bg: "var(--ok-soft)", fg: "var(--ok)", hoverBg: "color-mix(in oklch, var(--ok) 25%, transparent)", border: "transparent" },
    subtle: { bg: "var(--accent-soft)", fg: "var(--accent)", hoverBg: "color-mix(in oklch, var(--accent) 22%, transparent)", border: "transparent" },
  }[variant];
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      title={title}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: sizes.gap,
        height: sizes.h,
        padding: `0 ${sizes.px}px`,
        fontSize: sizes.fs,
        fontWeight: 600,
        lineHeight: 1,
        color: variants.fg,
        background: active ? variants.hoverBg : (hover ? variants.hoverBg : variants.bg),
        border: `1px solid ${variants.border}`,
        borderRadius: 8,
        transition: "background 120ms ease, color 120ms ease, transform 80ms ease",
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {icon}
      {children}
    </button>
  );
}

function Icon({ name, size = 16, strokeWidth = 2, color = "currentColor" }) {
  const paths = {
    "layers": "M12 2 2 7l10 5 10-5-10-5z M2 17l10 5 10-5 M2 12l10 5 10-5",
    "trophy": "M8 21h8 M12 17v4 M7 4h10v4a5 5 0 0 1-10 0V4z M7 4H4v2a3 3 0 0 0 3 3 M17 4h3v2a3 3 0 0 1-3 3",
    "activity": "M22 12h-4l-3 9L9 3l-3 9H2",
    "users": "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M23 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75",
    "settings": "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
    "shield": "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
    "search": "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.35-4.35",
    "grid": "M3 3h7v7H3z M14 3h7v7h-7z M14 14h7v7h-7z M3 14h7v7H3z",
    "list": "M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01",
    "plus": "M12 5v14 M5 12h14",
    "minus": "M5 12h14",
    "arrow-left": "M19 12H5 M12 19l-7-7 7-7",
    "arrow-right": "M5 12h14 M12 5l7 7-7 7",
    "arrow-up-right": "M7 17 17 7 M7 7h10v10",
    "arrow-down-right": "M7 7l10 10 M17 7v10H7",
    "chevron-down": "M6 9l6 6 6-6",
    "chevron-right": "M9 18l6-6-6-6",
    "clock": "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 6v6l4 2",
    "edit": "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7 M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z",
    "trash": "M3 6h18 M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2 M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6",
    "transfer": "M17 1l4 4-4 4 M3 11V9a4 4 0 0 1 4-4h14 M7 23l-4-4 4-4 M21 13v2a4 4 0 0 1-4 4H3",
    "target": "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12z M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z",
    "sun": "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10z M12 1v2 M12 21v2 M4.22 4.22l1.42 1.42 M18.36 18.36l1.42 1.42 M1 12h2 M21 12h2 M4.22 19.78l1.42-1.42 M18.36 5.64l1.42-1.42",
    "moon": "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z",
    "sun-moon": "M12 3v1 M12 20v1 M4.22 4.22l.7.7 M18.36 18.36l.7.7 M1 12h1 M22 12h-1 M4.22 19.78l.7-.7 M18.36 5.64l.7-.7 M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0",
    "filter": "M22 3H2l8 9.46V19l4 2v-8.54L22 3z",
    "calendar": "M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z M16 2v4 M8 2v4 M3 10h18",
    "trend-up": "M23 6l-9.5 9.5-5-5L1 18 M17 6h6v6",
    "trend-down": "M23 18l-9.5-9.5-5 5L1 6 M17 18h6v-6",
    "bell": "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9 M13.73 21a2 2 0 0 1-3.46 0",
    "log-out": "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9",
    "log-in": "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4 M10 17l5-5-5-5 M15 12H3",
    "sparkle": "M12 2l2 5 5 2-5 2-2 5-2-5-5-2 5-2z",
    "menu": "M3 12h18 M3 6h18 M3 18h18",
    "x": "M18 6 6 18 M6 6l12 12",
    "external": "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6 M15 3h6v6 M10 14 21 3",
  };
  const d = paths[name];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
      {d && d.split(" M").map((p, i) => <path key={i} d={(i === 0 ? p : "M" + p)} />)}
    </svg>
  );
}

/* Placeholder image: a warm gradient with category glyph and name */
function ResourceImage({ resource, size = "md" }) {
  const { name, category, tier } = resource;
  const cat = CATEGORIES[category] || CATEGORIES.other;
  const dims = size === "sm" ? { w: 40, h: 40, fs: 14 } : size === "lg" ? { w: 120, h: 120, fs: 26 } : { w: 56, h: 56, fs: 18 };
  // derive a hue from name
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  const initial = name.replace(/\b(BP|Mk\d+)\b/gi, "").trim().split(/\s+/).map(w => w[0]).slice(0, 2).join("");
  return (
    <div
      style={{
        width: dims.w, height: dims.h,
        borderRadius: 8,
        background: `linear-gradient(135deg, oklch(0.35 0.04 ${hue}) 0%, oklch(0.22 0.02 ${(hue + 40) % 360}) 100%)`,
        position: "relative",
        overflow: "hidden",
        flexShrink: 0,
        border: "1px solid var(--line)",
      }}
    >
      {/* subtle noise stripes */}
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, opacity: 0.2 }}>
        <defs>
          <pattern id={`p-${resource.id}`} x="0" y="0" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(35)">
            <line x1="0" y1="0" x2="0" y2="8" stroke="white" strokeWidth="0.8" opacity="0.2" />
          </pattern>
        </defs>
        <rect width="100" height="100" fill={`url(#p-${resource.id})`} />
      </svg>
      <div
        className="mono"
        style={{
          position: "absolute", inset: 0,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: dims.fs, fontWeight: 600,
          color: "oklch(0.95 0.02 80 / 0.92)",
          letterSpacing: 1,
        }}
      >{initial.toUpperCase()}</div>
      <div style={{ position: "absolute", left: 4, top: 4 }}>
        <TierPill tier={tier} />
      </div>
    </div>
  );
}

function Card({ children, style, className, padded = true }) {
  return (
    <div
      className={className}
      style={{
        background: "var(--bg-1)",
        border: "1px solid var(--line)",
        borderRadius: "var(--radius-lg)",
        padding: padded ? 20 : 0,
        boxShadow: "var(--shadow-sm)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function SectionHeader({ title, right, subtitle }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 14, gap: 12 }}>
      <div>
        <div style={{ fontSize: 14, fontWeight: 600, color: "var(--fg-1)", letterSpacing: 0.1 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12, color: "var(--fg-3)", marginTop: 2 }}>{subtitle}</div>}
      </div>
      {right}
    </div>
  );
}

Object.assign(window, {
  Chip, TierPill, StatusDot, StatusChip, Sparkline, Progress, Btn, Icon, ResourceImage, Card, SectionHeader,
});
