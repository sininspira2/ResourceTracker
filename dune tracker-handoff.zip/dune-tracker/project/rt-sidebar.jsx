/* Sidebar + mobile top bar navigation */

const NAV_ITEMS = [
  { id: "resources", label: "Resources", icon: "layers" },
  { id: "details", label: "Resource Details", icon: "sparkle", hidden: true },
  { id: "leaderboard", label: "Leaderboard", icon: "trophy" },
  { id: "activity", label: "Activity", icon: "activity" },
  { id: "contributors", label: "Contributors", icon: "users" },
  { id: "settings", label: "Settings", icon: "settings" },
  { id: "privacy", label: "Privacy", icon: "shield" },
];

function OrgMark({ collapsed }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: collapsed ? "0" : "0 4px", minWidth: 0 }}>
      <div
        style={{
          width: 32, height: 32, flexShrink: 0,
          borderRadius: 8,
          background: "linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 100%)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--accent-fg)",
          fontWeight: 700, fontSize: 13,
          boxShadow: "inset 0 0 0 1px oklch(1 0 0 / 0.1)",
          fontFamily: "var(--font-mono)",
          letterSpacing: -0.5,
        }}
      >RT</div>
      {!collapsed && (
        <div style={{ minWidth: 0, overflow: "hidden" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "var(--fg-1)", lineHeight: 1.2, whiteSpace: "nowrap" }}>Your Guild</div>
          <div style={{ fontSize: 10.5, color: "var(--fg-3)", fontFamily: "var(--font-mono)", letterSpacing: 0.3, marginTop: 2 }}>v4.3.0</div>
        </div>
      )}
    </div>
  );
}

function NavItem({ item, active, collapsed, onClick }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      title={collapsed ? item.label : ""}
      style={{
        width: "100%",
        display: "flex", alignItems: "center",
        gap: 12,
        padding: collapsed ? "10px 0" : "9px 12px",
        justifyContent: collapsed ? "center" : "flex-start",
        background: active ? "var(--accent-soft)" : (hover ? "var(--bg-2)" : "transparent"),
        color: active ? "var(--accent)" : "var(--fg-2)",
        border: "none",
        borderRadius: 8,
        fontSize: 13.5,
        fontWeight: active ? 600 : 500,
        cursor: "pointer",
        transition: "background 120ms ease, color 120ms ease",
        position: "relative",
      }}
    >
      {active && !collapsed && (
        <span style={{
          position: "absolute", left: -10, top: 8, bottom: 8,
          width: 3, background: "var(--accent)", borderRadius: 999,
        }} />
      )}
      <Icon name={item.icon} size={17} strokeWidth={active ? 2.2 : 1.8} />
      {!collapsed && <span>{item.label}</span>}
    </button>
  );
}

function ThemeSwitch({ theme, setTheme, compact }) {
  const opts = [
    { k: "light", icon: "sun" },
    { k: "dark", icon: "moon" },
    { k: "system", icon: "sun-moon" },
  ];
  return (
    <div
      style={{
        display: "inline-flex",
        background: "var(--bg-2)",
        borderRadius: 999,
        padding: 3,
        gap: 2,
        border: "1px solid var(--line)",
      }}
    >
      {opts.map(o => (
        <button
          key={o.k}
          onClick={() => setTheme(o.k)}
          title={o.k}
          style={{
            width: compact ? 26 : 28, height: compact ? 26 : 28,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: theme === o.k ? "var(--bg-1)" : "transparent",
            color: theme === o.k ? "var(--accent)" : "var(--fg-3)",
            border: "none",
            borderRadius: 999,
            cursor: "pointer",
            boxShadow: theme === o.k ? "0 1px 2px oklch(0 0 0 / 0.2)" : "none",
            transition: "background 120ms, color 120ms",
          }}
        >
          <Icon name={o.icon} size={14} strokeWidth={2} />
        </button>
      ))}
    </div>
  );
}

function UserBadge({ collapsed }) {
  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 10,
        padding: collapsed ? 0 : "8px 10px",
        background: collapsed ? "transparent" : "var(--bg-2)",
        border: collapsed ? "none" : "1px solid var(--line)",
        borderRadius: 10,
        minWidth: 0,
      }}
    >
      <div
        style={{
          width: 28, height: 28, borderRadius: 999, flexShrink: 0,
          background: "linear-gradient(135deg, oklch(0.65 0.15 280), oklch(0.6 0.15 200))",
          color: "oklch(0.98 0 0)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 11, fontWeight: 700,
          fontFamily: "var(--font-mono)",
        }}
      >S</div>
      {!collapsed && (
        <>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--fg-1)", lineHeight: 1.2 }}>sininspira</div>
            <div style={{ fontSize: 10.5, color: "var(--fg-3)", marginTop: 1 }}>Admin</div>
          </div>
          <button
            title="Sign out"
            style={{
              width: 28, height: 28,
              background: "transparent", border: "none", cursor: "pointer",
              color: "var(--fg-3)", borderRadius: 6,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          ><Icon name="log-out" size={14} /></button>
        </>
      )}
    </div>
  );
}

function Sidebar({ current, setCurrent, theme, setTheme, collapsed, setCollapsed }) {
  const visible = NAV_ITEMS.filter(i => !i.hidden);
  return (
    <aside
      style={{
        width: collapsed ? 68 : 232,
        flexShrink: 0,
        background: "var(--bg-1)",
        borderRight: "1px solid var(--line)",
        display: "flex",
        flexDirection: "column",
        padding: collapsed ? "16px 10px" : "16px 14px",
        gap: 18,
        position: "sticky",
        top: 0,
        height: "100vh",
        transition: "width 220ms cubic-bezier(0.4, 0, 0.2, 1)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <OrgMark collapsed={collapsed} />
        <button
          onClick={() => setCollapsed(!collapsed)}
          title={collapsed ? "Expand" : "Collapse"}
          style={{
            width: 26, height: 26,
            display: collapsed ? "none" : "flex",
            alignItems: "center", justifyContent: "center",
            background: "transparent", border: "1px solid var(--line)",
            borderRadius: 6, color: "var(--fg-3)",
            cursor: "pointer",
          }}
        ><Icon name="arrow-left" size={12} /></button>
      </div>

      {collapsed && (
        <button
          onClick={() => setCollapsed(false)}
          style={{
            width: "100%", height: 26,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "transparent", border: "1px solid var(--line)",
            borderRadius: 6, color: "var(--fg-3)",
            cursor: "pointer",
          }}
        ><Icon name="arrow-right" size={12} /></button>
      )}

      <nav style={{ display: "flex", flexDirection: "column", gap: 2, flex: 1 }}>
        {!collapsed && (
          <div style={{
            fontSize: 10, fontWeight: 600, color: "var(--fg-4)",
            letterSpacing: 1, textTransform: "uppercase",
            padding: "4px 12px 8px",
          }}>Tracker</div>
        )}
        {visible.slice(0, 4).map(item => (
          <NavItem
            key={item.id}
            item={item}
            active={current === item.id || (item.id === "resources" && current === "details")}
            collapsed={collapsed}
            onClick={() => setCurrent(item.id)}
          />
        ))}
        {!collapsed && (
          <div style={{
            fontSize: 10, fontWeight: 600, color: "var(--fg-4)",
            letterSpacing: 1, textTransform: "uppercase",
            padding: "14px 12px 8px",
          }}>Account</div>
        )}
        {collapsed && <div style={{ height: 8 }} />}
        {visible.slice(4).map(item => (
          <NavItem
            key={item.id}
            item={item}
            active={current === item.id}
            collapsed={collapsed}
            onClick={() => setCurrent(item.id)}
          />
        ))}
      </nav>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {!collapsed && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 4px" }}>
            <span style={{ fontSize: 11, color: "var(--fg-3)", fontWeight: 500 }}>Theme</span>
            <ThemeSwitch theme={theme} setTheme={setTheme} compact />
          </div>
        )}
        {collapsed && (
          <div style={{ display: "flex", justifyContent: "center" }}>
            <ThemeSwitch theme={theme} setTheme={setTheme} compact />
          </div>
        )}
        <UserBadge collapsed={collapsed} />
      </div>
    </aside>
  );
}

function MobileTopBar({ current, setCurrent, theme, setTheme, onMenu }) {
  const visible = NAV_ITEMS.filter(i => !i.hidden);
  const [menuOpen, setMenuOpen] = useState(false);
  const cur = visible.find(i => i.id === current) || visible[0];
  return (
    <>
      <header style={{
        position: "sticky", top: 0, zIndex: 30,
        background: "var(--bg-1)", borderBottom: "1px solid var(--line)",
        padding: "10px 16px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 12,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button
            onClick={() => setMenuOpen(true)}
            style={{
              width: 36, height: 36, borderRadius: 8,
              background: "var(--bg-2)", border: "1px solid var(--line)",
              color: "var(--fg-1)", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          ><Icon name="menu" size={18} /></button>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{
              width: 26, height: 26, borderRadius: 6,
              background: "linear-gradient(135deg, var(--accent), var(--accent-2))",
              color: "var(--accent-fg)", fontWeight: 700, fontSize: 11,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "var(--font-mono)",
            }}>RT</div>
            <div style={{ fontSize: 13.5, fontWeight: 600 }}>{cur.label}</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <ThemeSwitch theme={theme} setTheme={setTheme} compact />
        </div>
      </header>

      {menuOpen && (
        <div
          onClick={() => setMenuOpen(false)}
          style={{
            position: "fixed", inset: 0, zIndex: 50,
            background: "oklch(0 0 0 / 0.5)",
            animation: "fadeIn 150ms ease",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: "absolute", top: 0, left: 0, bottom: 0,
              width: 260, background: "var(--bg-1)",
              padding: 16,
              display: "flex", flexDirection: "column", gap: 14,
              animation: "slideIn 180ms ease",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <OrgMark />
              <button
                onClick={() => setMenuOpen(false)}
                style={{
                  width: 28, height: 28, borderRadius: 6,
                  background: "transparent", border: "1px solid var(--line)",
                  cursor: "pointer", color: "var(--fg-2)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}
              ><Icon name="x" size={14} /></button>
            </div>
            <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {visible.map(item => (
                <NavItem
                  key={item.id}
                  item={item}
                  active={current === item.id}
                  onClick={() => { setCurrent(item.id); setMenuOpen(false); }}
                />
              ))}
            </nav>
            <div style={{ flex: 1 }} />
            <UserBadge />
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn { from {opacity:0} to {opacity:1} }
        @keyframes slideIn { from {transform:translateX(-100%)} to {transform:translateX(0)} }
      `}</style>
    </>
  );
}

Object.assign(window, { Sidebar, MobileTopBar, NAV_ITEMS });
