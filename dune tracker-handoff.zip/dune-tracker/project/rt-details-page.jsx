/* Resource Details page */

function BigChart({ resource }) {
  // Generate time-series for 3 streams: total, hagga, deep desert
  const days = 14;
  const pts = [];
  const base = resource.total;
  let h = resource.q1, d = resource.q2;
  for (let i = 0; i < days; i++) {
    const n = ((resource.name.length * (i + 3) * 2654435761) % 100) / 100 - 0.5;
    h = Math.max(0, h + n * base * 0.08 - (i > days - 3 ? base * 0.05 : 0));
    d = Math.max(0, d + n * base * 0.04);
    pts.push({ i, h, d, t: h + d });
  }
  // Last point = current
  pts[pts.length - 1] = { i: days - 1, h: resource.q1, d: resource.q2, t: resource.total };

  const w = 860, hgt = 260, padL = 48, padR = 16, padT = 20, padB = 34;
  const maxV = Math.max(...pts.map(p => p.t), resource.target);
  const xScale = i => padL + (i / (days - 1)) * (w - padL - padR);
  const yScale = v => padT + (1 - v / maxV) * (hgt - padT - padB);

  const line = (key, color) => {
    const d = pts.map((p, i) => (i === 0 ? "M" : "L") + xScale(i) + "," + yScale(p[key])).join(" ");
    return (
      <g key={key}>
        <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p, i) => (
          <circle key={i} cx={xScale(i)} cy={yScale(p[key])} r="3" fill="var(--bg-1)" stroke={color} strokeWidth="1.5" />
        ))}
      </g>
    );
  };

  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(f => Math.round(maxV * f));
  const xTicks = [0, 3, 6, 9, 12, 13];
  const dayLabels = ["Apr 10","Apr 11","Apr 12","Apr 13","Apr 14","Apr 15","Apr 16","Apr 17","Apr 18","Apr 19","Apr 20","Apr 21","Apr 22","Apr 23"];

  return (
    <div style={{ width: "100%", overflow: "hidden" }}>
      <svg viewBox={`0 0 ${w} ${hgt}`} width="100%" style={{ display: "block" }}>
        {/* grid */}
        {yTicks.map((v, i) => (
          <g key={i}>
            <line x1={padL} y1={yScale(v)} x2={w - padR} y2={yScale(v)} stroke="var(--line)" strokeDasharray="3 4" />
            <text x={padL - 8} y={yScale(v)} fill="var(--fg-4)" fontSize="10" textAnchor="end" dominantBaseline="middle" fontFamily="var(--font-mono)">
              {fmtNum(v)}
            </text>
          </g>
        ))}
        {/* target line */}
        {resource.target > 0 && (
          <g>
            <line x1={padL} y1={yScale(resource.target)} x2={w - padR} y2={yScale(resource.target)} stroke="var(--accent)" strokeDasharray="4 4" strokeWidth="1.2" opacity="0.7" />
            <text x={w - padR} y={yScale(resource.target) - 6} fill="var(--accent)" fontSize="10" textAnchor="end" fontFamily="var(--font-mono)">
              TARGET · {fmtNum(resource.target)}
            </text>
          </g>
        )}
        {/* x labels */}
        {xTicks.map(i => (
          <text key={i} x={xScale(i)} y={hgt - 10} fill="var(--fg-4)" fontSize="10" textAnchor="middle">{dayLabels[i]}</text>
        ))}
        {/* lines */}
        {line("t", "var(--info)")}
        {line("h", "var(--ok)")}
        {line("d", "var(--warn)")}
      </svg>
    </div>
  );
}

function DetailsPage({ resource, onBack, density }) {
  const r = resource || RESOURCES.find(r => r.id === "spice-melange");
  const delta24 = Math.round((r.spark[r.spark.length - 1] - r.spark[r.spark.length - 3]) * r.total * 0.5);
  const pct = r.target > 0 ? Math.round((r.total / r.target) * 100) : null;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Breadcrumb */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "var(--fg-3)" }}>
        <button onClick={onBack} style={{
          background: "transparent", border: "none", color: "var(--fg-3)", cursor: "pointer",
          display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12.5, padding: 0,
        }}>
          <Icon name="arrow-left" size={13} /> Resources
        </button>
        <Icon name="chevron-right" size={11} color="var(--fg-4)" />
        <span style={{ color: "var(--fg-2)" }}>{CATEGORIES[r.category].label}</span>
        <Icon name="chevron-right" size={11} color="var(--fg-4)" />
        <span style={{ color: "var(--fg-1)" }}>{r.name}</span>
      </div>

      {/* Header card */}
      <Card>
        <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
          <ResourceImage resource={r} size="lg" />
          <div style={{ flex: 1, minWidth: 240 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", marginBottom: 6 }}>
              <h1 style={{ margin: 0, fontSize: 26, fontWeight: 700, color: "var(--fg-1)", letterSpacing: -0.3 }}>{r.name}</h1>
              <TierPill tier={r.tier} />
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
              <Chip color={CATEGORIES[r.category].c} soft="var(--bg-2)">{CATEGORIES[r.category].label}</Chip>
              <StatusChip status={r.status} />
              <Chip color="var(--fg-3)" soft="var(--bg-2)">{r.sub}</Chip>
            </div>
            <div style={{ fontSize: 12, color: "var(--fg-3)" }}>
              Last updated by <span style={{ color: "var(--fg-1)", fontWeight: 500 }}>{r.updater}</span> · {r.when}
            </div>
          </div>

          {/* Big numbers grid */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, minmax(120px, auto))",
            gap: 1,
            background: "var(--line)",
            borderRadius: 10,
            overflow: "hidden",
            border: "1px solid var(--line)",
          }}>
            <div style={{ padding: "14px 18px", background: "var(--bg-1)" }}>
              <div style={{ fontSize: 10.5, color: "var(--fg-3)", letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 600, marginBottom: 4 }}>Current</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 600, color: "var(--fg-1)", letterSpacing: -0.5, lineHeight: 1 }}>{fmtNum(r.total)}</div>
              <Sparkline data={r.spark} w={110} h={22} stroke={delta24 >= 0 ? "var(--ok)" : "var(--crit)"} strokeWidth={1.5} />
            </div>
            <div style={{ padding: "14px 18px", background: "var(--bg-1)" }}>
              <div style={{ fontSize: 10.5, color: "var(--fg-3)", letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 600, marginBottom: 4 }}>Target</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 600, color: "var(--accent)", letterSpacing: -0.5, lineHeight: 1 }}>{r.target > 0 ? fmtNum(r.target) : "—"}</div>
              {pct !== null && <div className="mono" style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 6 }}>{pct}% reached</div>}
            </div>
            <div style={{ padding: "14px 18px", background: "var(--bg-1)" }}>
              <div style={{ fontSize: 10.5, color: "var(--fg-3)", letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 600, marginBottom: 4 }}>24h Δ</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 600, color: delta24 >= 0 ? "var(--ok)" : "var(--crit)", letterSpacing: -0.5, lineHeight: 1 }}>
                {fmtDelta(delta24)}
              </div>
              <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 6, display: "inline-flex", alignItems: "center", gap: 4 }}>
                <Icon name={delta24 >= 0 ? "trend-up" : "trend-down"} size={11} />
                vs yesterday
              </div>
            </div>
          </div>
        </div>

        {/* Progress bar */}
        {r.target > 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, color: "var(--fg-3)", marginBottom: 6 }}>
              <span>Progress to target</span>
              <span className="mono" style={{ color: pct >= 100 ? "var(--ok)" : "var(--fg-2)" }}>{pct}%</span>
            </div>
            <Progress value={r.total} max={r.target} status={r.status} height={8} />
          </div>
        )}

        {/* Locations + actions */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr auto",
          gap: 14,
          marginTop: 18,
          paddingTop: 16,
          borderTop: "1px solid var(--line)",
        }} className="rt-loc-actions">
          <div style={{ background: "var(--bg-2)", padding: "10px 14px", borderRadius: 8, border: "1px solid var(--line)" }}>
            <div style={{ fontSize: 10.5, color: "var(--fg-3)", letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 600, marginBottom: 4 }}>Hagga</div>
            <div className="mono" style={{ fontSize: 18, fontWeight: 600, color: "var(--fg-1)" }}>{fmtNum(r.q1)}</div>
          </div>
          <div style={{ background: "var(--bg-2)", padding: "10px 14px", borderRadius: 8, border: "1px solid var(--line)" }}>
            <div style={{ fontSize: 10.5, color: "var(--fg-3)", letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 600, marginBottom: 4 }}>Deep Desert</div>
            <div className="mono" style={{ fontSize: 18, fontWeight: 600, color: "var(--fg-1)" }}>{fmtNum(r.q2)}</div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <Btn variant="primary" size="md" icon={<Icon name="plus" size={14} />}>Add/Remove</Btn>
            <Btn variant="secondary" size="md" icon={<Icon name="transfer" size={14} />}>Transfer</Btn>
            <Btn variant="secondary" size="md" icon={<Icon name="target" size={14} />}>Target</Btn>
            <Btn variant="ghost" size="md" icon={<Icon name="edit" size={14} />}>Edit</Btn>
          </div>
        </div>
      </Card>

      {/* Chart */}
      <Card>
        <SectionHeader
          title="Quantity Over Time"
          subtitle="Hover points for details · click to highlight · times update automatically"
          right={
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <Select
                value="7d"
                onChange={() => {}}
                options={[
                  { value: "24h", label: "Last 24h" },
                  { value: "7d", label: "Last 7 days" },
                  { value: "30d", label: "Last 30 days" },
                  { value: "all", label: "All time" },
                ]}
              />
            </div>
          }
        />
        <BigChart resource={r} />
        <div style={{ display: "flex", gap: 16, justifyContent: "center", marginTop: 12, flexWrap: "wrap", fontSize: 12 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--fg-2)" }}>
            <span style={{ width: 10, height: 10, borderRadius: 999, background: "var(--info)" }} />
            Total
          </div>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--fg-2)" }}>
            <span style={{ width: 10, height: 10, borderRadius: 999, background: "var(--ok)" }} />
            Hagga
          </div>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--fg-2)" }}>
            <span style={{ width: 10, height: 10, borderRadius: 999, background: "var(--warn)" }} />
            Deep Desert
          </div>
        </div>
      </Card>

      {/* Two-up: activity + contributors */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }} className="rt-two-up">
        <Card>
          <SectionHeader title="Recent Activity" subtitle="Actions on this resource" />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {ACTIVITY.filter(a => a.target === r.name || Math.random() < 0.7).slice(0, 5).map(a => <RecentUpdateRow key={a.id} item={a} />)}
          </div>
        </Card>
        <Card>
          <SectionHeader
            title={<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><Icon name="trophy" size={14} color="var(--accent)" /> Top Contributors</span>}
            subtitle="+/- changes only · administrative updates excluded"
            right={<Chip color="var(--fg-3)" soft="var(--bg-2)">Only ± changes count</Chip>}
          />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {LEADERS.slice(0, 4).map(l => <LeaderRow key={l.rank} leader={l} isYou={l.user === "sininspira"} />)}
          </div>
        </Card>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .rt-loc-actions { grid-template-columns: 1fr 1fr !important; }
          .rt-loc-actions > *:last-child { grid-column: 1 / -1; }
        }
      `}</style>
    </div>
  );
}

Object.assign(window, { DetailsPage });
